extern int plaindir_load(struct repoinfo *cinfo, Pool **sigpoolp);
