extern FILE *trydeltadownload(Solvable *s, const char *loc);
