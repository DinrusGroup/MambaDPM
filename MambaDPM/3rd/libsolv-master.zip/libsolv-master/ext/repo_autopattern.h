/*
 * Copyright (c) 2013, SUSE Inc.
 *
 * This program is licensed under the BSD license, read LICENSE.BSD
 * for further information
 */

#define ADD_NO_AUTOPRODUCTS	(1 << 8)

extern int repo_add_autopattern(Repo *repo, int flags);
