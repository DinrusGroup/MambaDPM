char *findmetalinkurl(FILE *fp, unsigned char *chksump, Id *chksumtypep);
char *findmirrorlisturl(FILE *fp);
