#include "sleep.h"

int main(void)
{
  millisleep(25000);
  return 0;
}
