int  read_installed_rpm(struct repoinfo *cinfo);
void commit_transactionelement_rpm(Pool *pool, Id type, Id p, FILE *fp);
