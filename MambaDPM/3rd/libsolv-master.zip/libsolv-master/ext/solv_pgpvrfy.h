/*
 * Copyright (c) 2013, SUSE Inc.
 *
 * This program is licensed under the BSD license, read LICENSE.BSD
 * for further information
 */

extern int solv_pgpvrfy(const unsigned char *pub, int publ, const unsigned char *sig, int sigl);

