extern struct repoinfo *read_repoinfos_urpmi(Pool *pool, int *nrepoinfosp);

