extern int mdk_load(struct repoinfo *cinfo, Pool **sigpoolp);
extern int mdk_load_ext(Repo *repo, Repodata *data);

