# Installation tests

The tests in this directory are meant to run on top of an installed simdjson library.
As such they are not meant to run as part of the main tests of the library, executed
while building. They should run after the installation step has completed.