#ifndef SIMDJSON_WESTMERE_ONDEMAND_H
#define SIMDJSON_WESTMERE_ONDEMAND_H

#include "simdjson/westmere/begin.h"
#include "simdjson/generic/ondemand/amalgamated.h"
#include "simdjson/westmere/end.h"

#endif // SIMDJSON_WESTMERE_IMPLEMENTATION_H
