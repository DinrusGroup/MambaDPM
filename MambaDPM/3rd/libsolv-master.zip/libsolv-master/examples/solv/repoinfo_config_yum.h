extern char *yum_substitute(Pool *pool, char *line);
extern struct repoinfo *read_repoinfos_yum(Pool *pool, int *nrepoinfosp);
