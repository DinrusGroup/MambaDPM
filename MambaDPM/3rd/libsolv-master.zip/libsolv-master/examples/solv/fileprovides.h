void addfileprovides(Pool *pool);
