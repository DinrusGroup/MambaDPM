/*
 * Copyright (c) 2007-2009, Novell Inc.
 *
 * This program is licensed under the BSD license, read LICENSE.BSD
 * for further information
 */

extern int repo_add_code11_products(Repo *repo, const char *dirpath, int flags);
extern int repo_add_products(Repo *repo, const char *proddir, int flags);
