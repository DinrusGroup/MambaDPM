extern struct repoinfo *read_repoinfos_debian(Pool *pool, int *nrepoinfosp);
