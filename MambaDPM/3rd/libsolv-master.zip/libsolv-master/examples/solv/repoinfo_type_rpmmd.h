extern int repomd_load_ext(Repo *repo, Repodata *data);
extern int repomd_load(struct repoinfo *cinfo, Pool **sigpoolp);
