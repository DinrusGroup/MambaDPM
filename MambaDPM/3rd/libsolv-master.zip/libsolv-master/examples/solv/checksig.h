extern int checksig(Pool *sigpool, FILE *fp, FILE *sigfp);
extern Pool *read_sigs();

